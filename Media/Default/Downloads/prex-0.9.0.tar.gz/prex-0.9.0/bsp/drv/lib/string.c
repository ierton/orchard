/*-
 * Copyright (c) 2005-2007, Kohsuke Ohtani
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the author nor the names of any co-contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <sys/types.h>
#include <ddi.h>

/*
 * Convert string to long integer
 * This version does not support minus value.
 */
long
atol(const char *str)
{
	long val = 0;

	while (*str == ' ')
		str++;
	while (*str >= '0' && *str <= '9') {
		val *= 10;
		val += (*str - '0');
		str++;
	}
	return val;
}

size_t
strnlen(const char *str, size_t count)
{
	const char *tmp;

	for (tmp = str; count-- && *tmp != '\0'; ++tmp);
	return (size_t)(tmp - str);
}

char *
strncpy(char *dest, const char *src, size_t count)
{
	char *tmp = dest;

	while (count-- && (*dest++ = *src++) != '\0');
	return tmp;
}

int
strncmp(const char *src, const char *tgt, size_t count)
{
	signed char res = 0;

	while (count) {
		if ((res = *src - *tgt++) != 0 || !*src++)
			break;
		count--;
	}
	return res;
}

/* Safer version of strncpy */
size_t
strlcpy(char *dest, const char *src, size_t count)
{
	const char *p = src;

	while (count-- && (*dest++ = *src++) != '\0');

	if (count == 0) {
		*dest = '\0';
		while (*src++);
	}
	return (size_t)(src - p - 1); /* count does not include NULL */
}

void *
memcpy(void *dest, const void *src, size_t count)
{
	char *tmp = (char *)dest, *s = (char *)src;

	ASSERT(count != 0);

	while (count--)
		*tmp++ = *s++;
	return dest;
}

void *
memset(void *dest, int ch, size_t count)
{
	char *p = (char *)dest;

	ASSERT(count != 0);

	while (count--)
		*p++ = (char)ch;
	return dest;
}
