/*	$NetBSD: setjmp.h,v 1.3 1998/09/16 23:51:27 thorpej Exp $	*/

#ifndef _PPC_SETJMP_H
#define _PPC_SETJMP_H

#define _JBLEN	100

#endif /* !_PPC_SETJMP_H */
