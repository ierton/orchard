/*	$NetBSD: bzero.c,v 1.8 1998/08/04 06:25:10 perry Exp $	*/

#define BZERO
#include "memset.c"
