/*	$NetBSD: strrchr.c,v 1.1 1998/08/04 04:48:17 perry Exp $	*/

#define STRRCHR
#include "rindex.c"
