#ifndef _ERRNO_H_
#define _ERRNO_H_

#include <sys/errno.h>

extern int errno;			/* global error number */

#endif /* !_ERRNO_H_ */
